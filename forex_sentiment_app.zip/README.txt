
# Forex Sentiment Tracker Beta

Deploy Instructions:

1. Upload this folder to a GitHub repository.
2. Go to https://vercel.com/ and create a New Project.
3. Import your GitHub repo.
4. Click Deploy.

Your Forex Sentiment Tracker will be online!
